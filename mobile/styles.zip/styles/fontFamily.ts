export const fontFamily = {
  medium: "Inter_500Medium",
  regular: "Inter_400Regular",
  semibold: "Inter_600SemiBold",
}
